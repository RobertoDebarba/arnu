cd /usr/bin
./arnu
